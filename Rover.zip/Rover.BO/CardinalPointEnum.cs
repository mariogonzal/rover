﻿
namespace Rover.BO
{
    public enum CardinalPoint
    {
        North,
        East,
        South,
        West
    }
}